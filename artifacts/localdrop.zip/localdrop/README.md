# LocalDrop — Zero-Storage Local File Transfer

A lightweight, privacy-first file transfer tool that runs entirely on your local network.

**No cloud. No accounts. No permanent storage.**  
Files travel directly between devices using WebRTC (DTLS-encrypted). The local server only helps devices find each other.

## Features

- **Connect by QR scan** — Open the page on your computer, scan the QR with your phone
- **Connect by room code** — Enter a short code on both devices
- **Local server host** — One device runs the server; others join over Wi-Fi
- Peer-to-peer file transfer (multiple files, drag & drop)
- Text messaging between devices
- Real-time progress bars
- Device names
- Works on any modern browser (desktop + mobile)
- Dark, modern UI
- Completely offline after the page loads (except optional STUN for connectivity)

## Quick Start

### 1. Requirements
- Python 3.7+ (no extra packages needed)

### 2. Run the server
```bash
cd localdrop
python3 server.py
```

You will see something like:
```
==================================================
  LocalDrop — Zero-storage local file transfer
==================================================
  Local URL:  http://192.168.1.42:8765
  Localhost:  http://127.0.0.1:8765
  ...
```

### 3. Connect devices
1. Open the Local URL in a browser on the host machine.
2. On another device on the **same Wi-Fi**:
   - Scan the QR code shown on the page, **or**
   - Manually enter the room code that appears after you click “Join / Create Room”.

### 4. Transfer
- Select a nearby device from the list.
- Drag files onto the drop zone (or click to select).
- Or type a text message and send.

## Advanced Tips

- **Custom room**: Type a room code before joining (e.g. `HOME` or `OFFICE`).
- **Multiple files**: Drop several files at once; they transfer sequentially.
- **Phone → Computer or vice-versa**: Both directions work.
- **Firewall**: If devices cannot see each other, allow incoming connections on port **8765**.
- **Change port**: Edit `PORT = 8765` at the top of `server.py`.
- **HTTPS**: For camera QR scanning on some phones you may want a local HTTPS setup (optional, not required for basic use).

## How it works

1. The Python server runs on your machine and serves the web UI.
2. Devices join a **room** (identified by a short code).
3. The server relays only tiny signaling messages (SDP offers/answers and ICE candidates).
4. Once WebRTC is established, the **file data never touches the server** — it goes peer-to-peer.
5. When you stop the server or leave the room, everything disappears.

## Security Notes

- All file data is encrypted in transit by WebRTC (DTLS).
- The signaling server is only on your local network.
- No files are written to disk by the server.
- Use only on trusted networks.

## Troubleshooting

| Problem | Solution |
|---------|----------|
| Devices don’t see each other | Make sure both are on the same Wi-Fi and the server is running |
| Transfer stuck | Refresh both pages and try again; check firewall |
| QR not scanning | Manually type the room code or open the URL directly |
| Large files slow | Normal for Wi-Fi; WebRTC uses your local network speed |

---

Built for private, zero-storage local transfers.  
Enjoy!
