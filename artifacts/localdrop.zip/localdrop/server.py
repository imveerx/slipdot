#!/usr/bin/env python3
"""
LocalDrop - Zero-storage local file transfer
Transfers files peer-to-peer over WebRTC (no cloud, no permanent storage).
Connect via QR code, room code, or local server URL.

Run: python3 server.py
Then open the printed URL on other devices on the same Wi-Fi.
"""

import http.server
import socketserver
import json
import uuid
import time
import os
import socket
from urllib.parse import urlparse, parse_qs
from pathlib import Path

PORT = 8765
HOST = "0.0.0.0"
ROOM_TIMEOUT = 300  # seconds

# In-memory store: { room_id: { "peers": { peer_id: {name, last_seen, signals: []} } } }
rooms = {}

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

class LocalDropHandler(http.server.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        # Quieter logs
        pass

    def send_json(self, data, status=200):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)

        if path == "/" or path == "/index.html":
            self.serve_file("index.html", "text/html")
        elif path == "/qrcode.min.js":
            self.serve_file("qrcode.min.js", "application/javascript")
        elif path == "/api/peers":
            self.handle_peers(qs)
        elif path == "/api/signals":
            self.handle_get_signals(qs)
        elif path == "/api/info":
            self.send_json({
                "local_ip": get_local_ip(),
                "port": PORT,
                "rooms": list(rooms.keys())
            })
        else:
            self.send_error(404)

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        try:
            data = json.loads(body) if body else {}
        except:
            data = {}

        if path == "/api/join":
            self.handle_join(data)
        elif path == "/api/signal":
            self.handle_post_signal(data)
        elif path == "/api/heartbeat":
            self.handle_heartbeat(data)
        else:
            self.send_error(404)

    def serve_file(self, filename, content_type):
        base = Path(__file__).parent
        fpath = base / filename
        if not fpath.exists():
            self.send_error(404)
            return
        content = fpath.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-cache")
        self.end_headers()
        self.wfile.write(content)

    def cleanup_rooms(self):
        now = time.time()
        for room_id in list(rooms.keys()):
            peers = rooms[room_id]["peers"]
            for pid in list(peers.keys()):
                if now - peers[pid]["last_seen"] > ROOM_TIMEOUT:
                    del peers[pid]
            if not peers:
                del rooms[room_id]

    def handle_join(self, data):
        self.cleanup_rooms()
        room = data.get("room", "").strip().upper() or "DEFAULT"
        name = data.get("name", "Anonymous")[:30]
        peer_id = str(uuid.uuid4())[:8]

        if room not in rooms:
            rooms[room] = {"peers": {}}
        rooms[room]["peers"][peer_id] = {
            "name": name,
            "last_seen": time.time(),
            "signals": []
        }
        self.send_json({"peer_id": peer_id, "room": room, "name": name})

    def handle_peers(self, qs):
        self.cleanup_rooms()
        room = qs.get("room", [""])[0].upper()
        my_id = qs.get("peer_id", [""])[0]
        if room not in rooms:
            self.send_json({"peers": []})
            return
        peers = []
        for pid, info in rooms[room]["peers"].items():
            if pid != my_id:
                peers.append({"id": pid, "name": info["name"]})
        self.send_json({"peers": peers})

    def handle_post_signal(self, data):
        room = data.get("room", "").upper()
        to_id = data.get("to")
        if room in rooms and to_id in rooms[room]["peers"]:
            rooms[room]["peers"][to_id]["signals"].append({
                "from": data.get("from"),
                "type": data.get("type"),  # offer, answer, ice
                "data": data.get("data")
            })
            rooms[room]["peers"][to_id]["last_seen"] = time.time()
        self.send_json({"ok": True})

    def handle_get_signals(self, qs):
        room = qs.get("room", [""])[0].upper()
        peer_id = qs.get("peer_id", [""])[0]
        if room in rooms and peer_id in rooms[room]["peers"]:
            sigs = rooms[room]["peers"][peer_id]["signals"]
            rooms[room]["peers"][peer_id]["signals"] = []
            rooms[room]["peers"][peer_id]["last_seen"] = time.time()
            self.send_json({"signals": sigs})
        else:
            self.send_json({"signals": []})

    def handle_heartbeat(self, data):
        room = data.get("room", "").upper()
        peer_id = data.get("peer_id")
        if room in rooms and peer_id in rooms[room]["peers"]:
            rooms[room]["peers"][peer_id]["last_seen"] = time.time()
            if "name" in data:
                rooms[room]["peers"][peer_id]["name"] = data["name"][:30]
        self.send_json({"ok": True})


def main():
    os.chdir(Path(__file__).parent)
    local_ip = get_local_ip()
    print("\n" + "="*50)
    print("  LocalDrop — Zero-storage local file transfer")
    print("="*50)
    print(f"  Local URL:  http://{local_ip}:{PORT}")
    print(f"  Localhost:  http://127.0.0.1:{PORT}")
    print("  Scan the QR code on the page to connect other devices.")
    print("  Or share the room code that appears after you open the page.")
    print("  Files never leave your local network and are never stored.")
    print("  Press Ctrl+C to stop.")
    print("="*50 + "\n")

    with socketserver.TCPServer((HOST, PORT), LocalDropHandler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down LocalDrop...")


if __name__ == "__main__":
    main()
